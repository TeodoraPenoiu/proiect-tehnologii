<div class="put-middle box-shadow mb-3" style="width: fit-content">
        <form method="post">
            <input type="hidden" name="comanda" value="login">
            <div class="mb-3" style="width: fit-content">
                <img src="../assets/img/email.png" alt="sigla email">
                <input id="email" type="text" placeholder="EMAIL" name="username">
            </div>
            <div class="mb-3" style="width: fit-content">
                <img src="../assets/img/password.png" alt="sigla parola">
                <input id="password" type="password" placeholder="PAROLA" name="password"">
            </div>
            <input type="submit" value="Login" class="btn btn-primary mb-3 w-100">
        </form>
</div>