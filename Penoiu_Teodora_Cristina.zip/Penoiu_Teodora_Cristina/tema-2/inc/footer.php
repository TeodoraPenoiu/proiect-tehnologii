</main>

<footer class="mt-auto footer-background footer-display">
    <div class="container">
        <h3 class="footer-title">DESPRE CONCURS</h3>
        <p class="footer-text flex-direction">Concursul este destinat tuturor elevilor de gimnaziu și liceu<br> care se pot încadra în probele concursului. Un elev poate<br> participa la una sau mai multe probe.</p>
        <p class="footer-text float-md-end"> &copy;Penoiu Teodora Cristina </p>
    </div>
</footer>

</body>
</html>