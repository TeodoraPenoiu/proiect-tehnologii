<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>X</title>

    <link rel="stylesheet" href="../../tema-1/B/assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/login.css">
    <link rel="stylesheet" href="../../tema-1/B/assets/css/regulament.css">
    <link rel="stylesheet" href="../../tema-1/B/assets/css/subiecte.css">
    <link rel="stylesheet" href="../../tema-1/B/assets/css/noutati.css">

    <!-- Bootstrap core CSS -->
    <link href="../assets/libs/bootstrap-5.0.0/css/bootstrap.min.css" rel="stylesheet">
    <script src="../assets/libs/bootstrap-5.0.0/js/bootstrap.bundle.min.js"></script>
</head>

<body>
<header class="mb-auto">
    <div class="container">
        <a href="../../tema-1/B/home.html"><img src="../../tema-1/B/assets/img/logo.png" class="header-logo" alt="sigla concurs"></a>
        <nav class="nav nav-masthead float-md-end">
            <a class="nav-link" aria-current="page" href="../../tema-1/B/home.html">Home</a>
            <a class="nav-link" href="../../tema-1/B/regulament.html">Regulament</a>
            <a class="nav-link make-space" href="../../tema-1/B/contact.html">Contact</a>
            <div class="pl-2 dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"></button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="../../tema-1/B/sponsori.html">Sponsori</a></li>
                    <li><a class="dropdown-item" href="../../tema-1/B/organizatori.html">Organizatori</a></li>
                    <li><a class="dropdown-item" href="../participanti.php">Participanti</a></li>
                    <li><a class="dropdown-item" href="../admin/login.php">Intra in cont</a></li>
                    <li><a class="dropdown-item" href="../inscriere.php">Inscriete-te!</a></li>
                </ul>
            </div>
        </nav>
    </div>
</header>

<main>